import AppKit
import Network

extension Notification.Name {
    /// Asks the controls window to open (or bring forward) the lyrics window.
    /// `openWindow` only exists inside SwiftUI views, so anything outside one —
    /// the Stream Deck, here — has to ask a view to do it.
    static let showLyricsWindow = Notification.Name("StudioOne.showLyricsWindow")
}

/// A control port for the Stream Deck plug-in, reachable only from this Mac.
///
/// The guest request line already speaks HTTP, but it only runs while a session
/// is open and only for Apple Music, and it is built for phones on the Wi-Fi.
/// This one is always on, listens on 127.0.0.1 alone, and answers only requests
/// carrying a token.
///
/// The token matters even on the loopback address, because a web page in any
/// browser on this Mac can send requests to 127.0.0.1. A custom header cannot
/// be attached to a cross-site request without the browser first asking
/// permission, which this server never grants, so a page can't drive playback.
/// The token and the port are written to a file only this user can read; the
/// plug-in reads them from there, so there is nothing to type in.
@MainActor
final class ControlServer {

    static let shared = ControlServer()

    /// Above the request line (8710–8719) and the Spotify sign-in (8725).
    static let ports: ClosedRange<UInt16> = 8730...8739

    static var infoURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Studio One", isDirectory: true)
            .appendingPathComponent("control.json")
    }

    private(set) var port: UInt16?
    private var listener: NWListener?
    private weak var model: KaraokeModel?
    private let queue = DispatchQueue(label: "com.logan.SpotifyKaraoke.control")
    private lazy var token: String = existingToken() ?? Self.makeToken()

    /// Reading the volume is an Apple Event round trip. The deck polls twice a
    /// second, so the value is cached and refreshed in the background instead.
    private var volume: Int?
    private var volumeFetchedAt = Date.distantPast
    private var mutedFrom: Int?

    private var artwork: (track: String, data: Data)?

    func start(model: KaraokeModel) {
        self.model = model
        guard listener == nil else { return }
        for candidate in Self.ports {
            let parameters = NWParameters.tcp
            parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1",
                                                         port: NWEndpoint.Port(rawValue: candidate)!)
            guard let listener = try? NWListener(using: parameters) else { continue }
            listener.newConnectionHandler = { [weak self] connection in
                Task { @MainActor in self?.accept(connection) }
            }
            listener.stateUpdateHandler = { [weak self] state in
                if case .failed = state {
                    Task { @MainActor in
                        self?.listener = nil
                        self?.port = nil
                    }
                }
            }
            listener.start(queue: queue)
            self.listener = listener
            port = candidate
            writeInfo()
            Diagnostics.log("stream deck: control port \(candidate)")
            return
        }
        Diagnostics.log("stream deck: no free control port in \(Self.ports)")
    }

    // MARK: - HTTP

    private func accept(_ connection: NWConnection) {
        connection.start(queue: queue)
        receive(on: connection, buffer: Data())
    }

    private func receive(on connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { [weak self] data, _, done, error in
            var buffer = buffer
            if let data { buffer.append(data) }
            Task { @MainActor in
                guard let self else { return }
                if let request = Self.parse(buffer) {
                    await self.respond(to: request, on: connection)
                } else if done || error != nil || buffer.count > 65_536 {
                    connection.cancel()
                } else {
                    self.receive(on: connection, buffer: buffer)
                }
            }
        }
    }

    struct Request {
        let method: String
        let path: String
        let headers: [String: String]
        let body: Data
    }

    /// Nil until the whole request, body included, has arrived.
    static func parse(_ data: Data) -> Request? {
        guard let split = data.range(of: Data("\r\n\r\n".utf8)),
              let head = String(data: data[..<split.lowerBound], encoding: .utf8) else { return nil }
        let lines = head.components(separatedBy: "\r\n")
        let parts = lines.first?.split(separator: " ") ?? []
        guard parts.count >= 2 else { return nil }
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            headers[line[..<colon].lowercased()] = line[line.index(after: colon)...]
                .trimmingCharacters(in: .whitespaces)
        }
        let length = Int(headers["content-length"] ?? "0") ?? 0
        let body = data[split.upperBound...]
        guard body.count >= length else { return nil }
        return Request(method: String(parts[0]), path: String(parts[1]),
                       headers: headers, body: Data(body.prefix(length)))
    }

    private func respond(to request: Request, on connection: NWConnection) async {
        guard request.headers["x-studio-one-token"] == token else {
            return send(401, json: ["error": "bad token"], on: connection)
        }
        switch (request.method, request.path) {
        case ("GET", "/state"):
            send(200, json: state(), on: connection)
        case ("GET", "/artwork"):
            if let data = await currentArtwork() {
                send(200, type: "image/png", body: data, on: connection)
            } else {
                send(404, json: ["error": "no artwork"], on: connection)
            }
        case ("POST", "/command"):
            let object = (try? JSONSerialization.jsonObject(with: request.body)) as? [String: Any] ?? [:]
            let command = object["command"] as? String ?? ""
            let amount = (object["amount"] as? NSNumber)?.doubleValue ?? 0
            let result = await perform(command, amount: amount)
            send(result == nil ? 200 : 400,
                 json: result.map { ["error": $0] } ?? ["ok": true, "state": state()],
                 on: connection)
        default:
            send(404, json: ["error": "not found"], on: connection)
        }
    }

    private func send(_ status: Int, json: [String: Any], on connection: NWConnection) {
        let body = (try? JSONSerialization.data(withJSONObject: json)) ?? Data("{}".utf8)
        send(status, type: "application/json", body: body, on: connection)
    }

    private func send(_ status: Int, type: String, body: Data, on connection: NWConnection) {
        let reason = [200: "OK", 400: "Bad Request", 401: "Unauthorized", 404: "Not Found"][status] ?? "OK"
        let head = "HTTP/1.1 \(status) \(reason)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nConnection: close\r\n\r\n"
        connection.send(content: Data(head.utf8) + body, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    // MARK: - State

    private func state() -> [String: Any] {
        guard let model else { return ["running": false] }
        refreshVolumeIfStale()
        let shown = model.publishedAnalysis
        var state: [String: Any] = [
            "running": true,
            "source": model.musicSource == .spotify ? "spotify" : "appleMusic",
            "sourceName": model.musicSource.displayName,
            "connected": model.connection == .ready,
            "playing": model.isPlaying,
            "position": model.playbackPosition,
            "lyricOffsetMs": model.offsetMilliseconds,
            "fontSize": UserDefaults.standard.object(forKey: "lyricFontSize") as? Double ?? 42,
            "tempoMultiplier": model.tempoMultiplier,
            "keyIsManual": model.manualKey != nil,
            "tempoIsManual": model.manualTempo != nil,
            "lyrics": Self.name(of: model.lyricsState),
            "midiEnabled": UserDefaults.standard.bool(forKey: MIDIBridge.enabledKey),
            "lastSent": MIDIBridge.shared.lastSent,
        ]
        if let track = model.track {
            state["title"] = track.name
            state["artist"] = track.artist
            state["duration"] = track.duration
            state["trackID"] = track.uri
        }
        if let key = shown?.key { state["key"] = key }
        if let key = model.analysis?.key { state["detectedKey"] = key }
        if let tempo = shown?.tempo { state["bpm"] = tempo }
        if let volume { state["volume"] = volume }
        return state
    }

    private static func name(of state: LyricsState) -> String {
        switch state {
        case .idle: return "idle"
        case .loading: return "loading"
        case .synced: return "synced"
        case .plain: return "plain"
        case .instrumental: return "instrumental"
        case .missing: return "missing"
        }
    }

    private func refreshVolumeIfStale() {
        guard Date().timeIntervalSince(volumeFetchedAt) > 2, let browser = model?.browser else { return }
        volumeFetchedAt = Date()
        Task { @MainActor in self.volume = await browser.volume() }
    }

    // MARK: - Commands

    /// Nil on success, or why not.
    private func perform(_ command: String, amount: Double) async -> String? {
        guard let model else { return "not ready" }
        switch command {
        case "playPause":    model.togglePlayback()
        case "next":         model.nextTrack()
        case "previous":     model.previousTrack()
        case "seekBy":
            let length = model.track?.duration ?? 0
            model.seek(to: min(max(0, model.playbackPosition + amount), max(0, length - 1)))

        case "keyBy":        model.nudgeKey(by: Int(amount))
        case "keyReset":     model.manualKey = nil
        case "tempoBy":      model.nudgeTempo(by: amount)
        case "tempoReset":
            model.manualTempo = nil
            model.tempoMultiplier = 1
        case "tempoDouble":  model.tempoMultiplier = min(4, model.tempoMultiplier * 2)
        case "tempoHalf":    model.tempoMultiplier = max(0.25, model.tempoMultiplier / 2)

        case "lyricsBy":     model.offsetMilliseconds += amount
        case "lyricsReset":  model.offsetMilliseconds = 0
        case "reloadLyrics": model.reloadLyrics()

        case "fontBy":
            let current = UserDefaults.standard.object(forKey: "lyricFontSize") as? Double ?? 42
            UserDefaults.standard.set(min(96, max(24, current + amount)), forKey: "lyricFontSize")
        case "fontReset":
            UserDefaults.standard.set(42.0, forKey: "lyricFontSize")

        case "volumeBy", "volumeMute":
            guard let browser = model.browser else { return "no volume on this source" }
            let current: Int
            if let volume { current = volume } else { current = await browser.volume() }
            let target: Int
            if command == "volumeMute" {
                if current == 0, let previous = mutedFrom { target = previous; mutedFrom = nil }
                else { mutedFrom = current; target = 0 }
            } else {
                target = min(100, max(0, current + Int(amount)))
            }
            await browser.setVolume(target)
            volume = target
            volumeFetchedAt = Date()

        case "showLyrics":
            NSApp.activate(ignoringOtherApps: true)
            NotificationCenter.default.post(name: .showLyricsWindow, object: nil)
        case "lyricsFullScreen":
            NSApp.activate(ignoringOtherApps: true)
            if let window = Self.lyricsWindow {
                window.toggleFullScreen(nil)
            } else {
                // Not open yet: open it, then give it a moment to exist.
                NotificationCenter.default.post(name: .showLyricsWindow, object: nil)
                try? await Task.sleep(nanoseconds: 600_000_000)
                Self.lyricsWindow?.toggleFullScreen(nil)
            }

        case "sendKey":
            guard UserDefaults.standard.bool(forKey: MIDIBridge.enabledKey) else {
                return "MIDI to Logic is off in Settings"
            }
            MIDIBridge.shared.publish(model.publishedAnalysis)

        case "toggleSource":
            model.changeSource(to: model.musicSource == .spotify ? .appleMusic : .spotify)

        default:
            return "unknown command \(command)"
        }
        return nil
    }

    private static var lyricsWindow: NSWindow? {
        NSApp.windows.first { $0.title == "Lyrics" && $0.isVisible }
    }

    // MARK: - Artwork

    /// 144 px square PNG — a Stream Deck key's full resolution — cached per
    /// track, since the key only needs a new picture when the song changes.
    private func currentArtwork() async -> Data? {
        guard let model, let track = model.track else { return nil }
        if let artwork, artwork.track == track.uri { return artwork.data }

        var image: NSImage? = model.localArtwork
        if image == nil, let url = track.artworkURL,
           let (data, _) = try? await URLSession.shared.data(from: url) {
            image = NSImage(data: data)
        }
        guard let image, let png = Self.squarePNG(image, side: 144) else { return nil }
        artwork = (track.uri, png)
        return png
    }

    static func squarePNG(_ image: NSImage, side: Int) -> Data? {
        guard let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: side, pixelsHigh: side,
                                         bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                         isPlanar: false, colorSpaceName: .deviceRGB,
                                         bytesPerRow: 0, bitsPerPixel: 0) else { return nil }
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
        // Fill, not fit: crop the long side so the key has no bars.
        let size = image.size
        let crop = min(size.width, size.height)
        let source = NSRect(x: (size.width - crop) / 2, y: (size.height - crop) / 2, width: crop, height: crop)
        image.draw(in: NSRect(x: 0, y: 0, width: side, height: side), from: source,
                   operation: .copy, fraction: 1)
        NSGraphicsContext.restoreGraphicsState()
        return rep.representation(using: .png, properties: [:])
    }

    // MARK: - Token file

    private func writeInfo() {
        guard let port else { return }
        let url = Self.infoURL
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(),
                                                 withIntermediateDirectories: true)
        let info: [String: Any] = ["port": Int(port), "token": token]
        guard let data = try? JSONSerialization.data(withJSONObject: info) else { return }
        // Owner read/write only: the token is what stops anything else on this
        // Mac from driving playback through the port.
        FileManager.default.createFile(atPath: url.path, contents: data,
                                       attributes: [.posixPermissions: 0o600])
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }

    /// Kept across launches, so a plug-in that read it once keeps working.
    private func existingToken() -> String? {
        guard let data = try? Data(contentsOf: Self.infoURL),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let token = object["token"] as? String, token.count >= 32 else { return nil }
        return token
    }

    private static func makeToken() -> String {
        var bytes = [UInt8](repeating: 0, count: 24)
        _ = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
        return bytes.map { String(format: "%02x", $0) }.joined()
    }
}
