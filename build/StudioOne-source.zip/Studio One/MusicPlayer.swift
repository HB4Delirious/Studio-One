import AppKit

/// Which app is driving playback.
enum MusicSource: String, CaseIterable, Identifiable {
    case spotify
    case appleMusic

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .spotify:    return "Spotify"
        case .appleMusic: return "Apple Music"
        }
    }

    var bundleID: String {
        switch self {
        case .spotify:    return "com.spotify.client"
        case .appleMusic: return "com.apple.Music"
        }
    }

    var isInstalled: Bool {
        NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) != nil
    }

    var isRunning: Bool {
        !NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).isEmpty
    }

    static let defaultsKey = "musicSource"
}

/// What the app needs from a player, whichever one is driving.
///
/// Both implementations talk over Apple Events — the same mechanism the handoff
/// notes chose for Spotify, and the reason Apple Music slots in without a new
/// playback architecture.
protocol MusicPlayer: AnyObject, Sendable {
    var source: MusicSource { get }

    /// Whether the player can be told to start a specific track by identifier.
    /// Spotify can, via `play track "spotify:track:…"`; Music cannot usefully.
    var supportsPlayingByID: Bool { get }

    /// Async on purpose: the underlying Apple Event is synchronous and can take
    /// tens of milliseconds — occasionally far more when the player app is busy.
    /// Run on the main thread it blocks drawing, which shows up as stuttering
    /// animation and a highlight that advances in steps instead of gliding.
    func snapshot() async throws -> SpotifySnapshot
    func playPause() throws
    func next() throws
    func previous() throws
    func seek(to seconds: Double) throws
    func play(uri: String) throws
    func activate()
}
