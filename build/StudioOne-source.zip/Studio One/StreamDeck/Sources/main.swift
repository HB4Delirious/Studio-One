import Foundation

// Studio One for Stream Deck.
//
// A native plug-in: the Stream Deck app starts this executable with the port of
// its WebSocket and an identity to register under, then sends key, dial and
// touch events over that socket and accepts titles, images and touch-strip
// feedback back. Elgato's own examples include native executables alongside
// Node scripts; this one is Swift so it builds with nothing the app's own
// build doesn't already need.
//
// Studio One is reached through its control port on 127.0.0.1. The port and
// token are read from the file Studio One writes, so nothing is configured.

// MARK: - Launch arguments

func argument(_ name: String) -> String? {
    let args = CommandLine.arguments
    guard let index = args.firstIndex(of: name), index + 1 < args.count else { return nil }
    return args[index + 1]
}

// Plain top-level constants rather than `guard let`: a class can't capture
// values bound by top-level control flow, but it can read globals.
let deckPort = argument("-port") ?? ""
let pluginUUID = argument("-pluginUUID") ?? ""
let registerEvent = argument("-registerEvent") ?? ""
if deckPort.isEmpty || pluginUUID.isEmpty || registerEvent.isEmpty {
    FileHandle.standardError.write(Data("Studio One: started without Stream Deck's arguments\n".utf8))
    exit(1)
}

let prefix = "com.logan.studioone."

// MARK: - Studio One client

/// The control port, found through the file Studio One writes on launch.
final class StudioOne {
    private var port: Int?
    private var token: String?
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 3
        return URLSession(configuration: config)
    }()

    static var infoURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support/Studio One/control.json")
    }

    /// Re-read every time a request fails: Studio One may have been restarted
    /// on a different port.
    private func loadInfo() -> Bool {
        guard let data = try? Data(contentsOf: Self.infoURL),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let port = object["port"] as? Int, let token = object["token"] as? String else { return false }
        self.port = port
        self.token = token
        return true
    }

    private func request(_ path: String, body: [String: Any]? = nil,
                         done: @escaping (Data?, Int) -> Void) {
        if port == nil, !loadInfo() { return done(nil, 0) }
        var request = URLRequest(url: URL(string: "http://127.0.0.1:\(port!)\(path)")!)
        request.setValue(token, forHTTPHeaderField: "X-Studio-One-Token")
        if let body {
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }
        session.dataTask(with: request) { [weak self] data, response, _ in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if status == 0 || status == 401 { self?.port = nil }   // look again next time
            DispatchQueue.main.async { done(data, status) }
        }.resume()
    }

    func state(_ done: @escaping ([String: Any]?) -> Void) {
        request("/state") { data, status in
            done(status == 200 ? data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } : nil)
        }
    }

    /// The state after the command, or the reason it failed.
    func command(_ name: String, amount: Double = 0,
                 _ done: @escaping ([String: Any]?, String?) -> Void) {
        request("/command", body: ["command": name, "amount": amount]) { data, status in
            let object = data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            if status == 200 { done(object?["state"] as? [String: Any], nil) }
            else { done(nil, object?["error"] as? String ?? (status == 0 ? "Studio One isn't open" : "HTTP \(status)")) }
        }
    }

    func artwork(_ done: @escaping (Data?) -> Void) {
        request("/artwork") { data, status in done(status == 200 ? data : nil) }
    }
}

// MARK: - Stream Deck connection

final class Deck: NSObject, URLSessionWebSocketDelegate {
    private var socket: URLSessionWebSocketTask!
    private let studio = StudioOne()

    /// Every action on screen: context → action UUID.
    private var visible: [String: String] = [:]
    /// What was last sent to each context, so a poll that changes nothing sends nothing.
    private var lastSent: [String: String] = [:]
    private var state: [String: Any]?
    private var artworkTrack: String?
    private var artworkURL: String?
    private var pollTimer: Timer?

    func connect() {
        let session = URLSession(configuration: .default, delegate: self, delegateQueue: .main)
        socket = session.webSocketTask(with: URL(string: "ws://127.0.0.1:\(deckPort)")!)
        socket.resume()
        send(["event": registerEvent, "uuid": pluginUUID])
        receive()
    }

    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask,
                    didCloseWith closeCode: URLSessionWebSocketTask.CloseCode, reason: Data?) {
        exit(0)   // Stream Deck quit or unloaded the plug-in.
    }

    private func receive() {
        socket.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .success(.string(let text)):
                if let data = text.data(using: .utf8),
                   let event = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    self.handle(event)
                }
                self.receive()
            case .success:
                self.receive()
            case .failure:
                exit(0)
            }
        }
    }

    private func send(_ message: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: message),
              let text = String(data: data, encoding: .utf8) else { return }
        socket.send(.string(text)) { _ in }
    }

    private func log(_ message: String) {
        send(["event": "logMessage", "payload": ["message": "Studio One: \(message)"]])
    }

    // MARK: Events

    private func handle(_ event: [String: Any]) {
        guard let name = event["event"] as? String else { return }
        let context = event["context"] as? String ?? ""
        let action = (event["action"] as? String ?? "").replacingOccurrences(of: prefix, with: "")
        let payload = event["payload"] as? [String: Any] ?? [:]

        switch name {
        case "willAppear":
            visible[context] = action
            // A key coming back (a page switch) has been cleared by Stream Deck;
            // forget what it last showed, or the redraw would be skipped as a repeat.
            forget(context)
            startPolling()
            if let state { render(context, action, state) } else { poll() }
        case "willDisappear":
            visible[context] = nil
            forget(context)
            if visible.isEmpty { pollTimer?.invalidate(); pollTimer = nil }
        case "keyDown":
            keyDown(context, action)
        case "dialRotate":
            let ticks = (payload["ticks"] as? NSNumber)?.doubleValue ?? 0
            dialRotate(context, action, ticks)
        case "dialDown":
            dialPush(context, action)
        case "touchTap":
            touch(context, action, hold: payload["hold"] as? Bool ?? false)
        case "systemDidWakeUp":
            poll()
        default:
            break
        }
    }

    private func keyDown(_ context: String, _ action: String) {
        switch action {
        case "playpause":     run("playPause", context)
        case "next":          run("next", context)
        case "previous":      run("previous", context)
        case "nowplaying":    run("showLyrics", context)
        case "keybpm":        run("sendKey", context, confirm: true)
        case "lyricsfull":    run("lyricsFullScreen", context)
        case "source":        run("toggleSource", context)
        case "reload":        run("reloadLyrics", context, confirm: true)
        default: break
        }
    }

    private func dialRotate(_ context: String, _ action: String, _ ticks: Double) {
        switch action {
        case "dial.key":      run("keyBy", context, amount: ticks)
        case "dial.tempo":    run("tempoBy", context, amount: ticks)
        case "dial.sync":     run("lyricsBy", context, amount: ticks * 50)
        case "dial.volume":   run("volumeBy", context, amount: ticks * 2)
        case "dial.seek":     run("seekBy", context, amount: ticks * 5)
        case "dial.font":     run("fontBy", context, amount: ticks * 2)
        default: break
        }
    }

    private func dialPush(_ context: String, _ action: String) {
        switch action {
        case "dial.key":      run("keyReset", context)
        case "dial.tempo":    run("tempoReset", context)
        case "dial.sync":     run("lyricsReset", context)
        case "dial.volume":   run("volumeMute", context)
        case "dial.seek":     run("playPause", context)
        case "dial.font":     run("fontReset", context)
        default: break
        }
    }

    private func touch(_ context: String, _ action: String, hold: Bool) {
        switch action {
        case "dial.key":      run("sendKey", context, confirm: true)
        case "dial.tempo":    run(hold ? "tempoHalf" : "tempoDouble", context)
        case "dial.sync":     run("reloadLyrics", context, confirm: true)
        case "dial.seek":     run(hold ? "previous" : "next", context)
        default: break
        }
    }

    /// Sends a command and redraws everything from the state it returns, so a
    /// turn of the dial shows up at once rather than on the next poll.
    private func run(_ command: String, _ context: String, amount: Double = 0, confirm: Bool = false) {
        studio.command(command, amount: amount) { [weak self] state, error in
            guard let self else { return }
            if let error {
                self.log("\(command): \(error)")
                self.send(["event": "showAlert", "context": context])
                return
            }
            if confirm { self.send(["event": "showOk", "context": context]) }
            if let state { self.apply(state) }
        }
    }

    // MARK: Polling

    private func startPolling() {
        guard pollTimer == nil else { return }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.poll() }
    }

    private func poll() {
        studio.state { [weak self] state in
            guard let self else { return }
            if let state { self.apply(state) } else { self.showOffline() }
        }
    }

    private func apply(_ state: [String: Any]) {
        self.state = state
        let track = state["trackID"] as? String
        if track != artworkTrack {
            artworkTrack = track
            artworkURL = nil
            if track != nil {
                studio.artwork { [weak self] data in
                    guard let self, self.artworkTrack == track else { return }
                    self.artworkURL = data.map { "data:image/png;base64," + $0.base64EncodedString() }
                    self.renderAll()
                }
            }
        }
        renderAll()
    }

    private func renderAll() {
        guard let state else { return }
        for (context, action) in visible { render(context, action, state) }
    }

    private func showOffline() {
        state = nil
        for (context, action) in visible {
            if action.hasPrefix("dial.") {
                feedback(context, ["title": "Studio One", "value": "Not open", "indicator": ["value": 0]])
            } else {
                title(context, "Studio One\nnot open")
            }
        }
    }

    // MARK: Drawing

    private func render(_ context: String, _ action: String, _ s: [String: Any]) {
        let playing = s["playing"] as? Bool ?? false
        let key = s["key"] as? String
        let bpm = (s["bpm"] as? NSNumber)?.doubleValue
        let multiplier = (s["tempoMultiplier"] as? NSNumber)?.doubleValue ?? 1
        let position = (s["position"] as? NSNumber)?.doubleValue ?? 0
        let duration = (s["duration"] as? NSNumber)?.doubleValue ?? 0

        switch action {
        case "playpause":
            setState(context, playing ? 1 : 0)
            title(context, "")
        case "next", "previous", "lyricsfull", "reload":
            title(context, "")
        case "nowplaying":
            image(context, artworkURL)
            title(context, artworkURL == nil ? short(s["title"] as? String ?? "Nothing\nplaying", 18) : "")
        case "keybpm":
            let bpmText = bpm.map { "\(Int($0.rounded()))" } ?? "—"
            title(context, "\(key ?? "—")\n\(bpmText) BPM")
        case "source":
            title(context, (s["source"] as? String) == "spotify" ? "Spotify" : "Apple\nMusic")

        case "dial.key":
            let manual = s["keyIsManual"] as? Bool ?? false
            let shift = Keys.shift(from: s["detectedKey"] as? String, to: key)
            let shiftText = shift.map { $0 == 0 ? "" : String(format: " (%+d)", $0) } ?? ""
            feedback(context, ["title": manual ? "KEY · manual" : "KEY",
                               "value": (key ?? "—") + shiftText,
                               "indicator": ["value": Int((Double((shift ?? 0) + 6) / 12 * 100).rounded())]])
        case "dial.tempo":
            let times = multiplier == 1 ? "" : (multiplier > 1 ? " ×\(Int(multiplier))" : " ÷\(Int(1 / multiplier))")
            let manual = s["tempoIsManual"] as? Bool ?? false
            feedback(context, ["title": manual ? "TEMPO · manual" : "TEMPO",
                               "value": (bpm.map { "\(Int($0.rounded())) BPM" } ?? "—") + times,
                               "indicator": ["value": Int(min(100, max(0, ((bpm ?? 60) - 60) / 120 * 100)))]])
        case "dial.sync":
            let offset = (s["lyricOffsetMs"] as? NSNumber)?.doubleValue ?? 0
            feedback(context, ["title": "LYRIC SYNC",
                               "value": offset == 0 ? "In sync" : String(format: "%+.0f ms", offset),
                               "indicator": ["value": Int(min(100, max(0, (offset + 1000) / 2000 * 100)))]])
        case "dial.volume":
            let volume = (s["volume"] as? NSNumber)?.intValue
            feedback(context, ["title": "VOLUME",
                               "value": volume.map { $0 == 0 ? "Muted" : "\($0)" } ?? "—",
                               "indicator": ["value": volume ?? 0]])
        case "dial.seek":
            var payload: [String: Any] = [
                "title": short(s["title"] as? String ?? "Nothing playing", 20),
                "value": duration > 0 ? "\(clock(position)) / \(clock(duration))" : "—",
                "indicator": ["value": duration > 0 ? Int(position / duration * 100) : 0]]
            if let artworkURL { payload["icon"] = artworkURL }
            feedback(context, payload)
        case "dial.font":
            let size = (s["fontSize"] as? NSNumber)?.doubleValue ?? 42
            feedback(context, ["title": "LYRIC SIZE",
                               "value": "\(Int(size)) pt",
                               "indicator": ["value": Int((size - 24) / 72 * 100)]])
        default:
            break
        }
    }

    private func title(_ context: String, _ text: String) {
        sendOnce(context, "title", ["event": "setTitle", "context": context,
                                    "payload": ["title": text, "target": 0]])
    }

    private func image(_ context: String, _ dataURL: String?) {
        var payload: [String: Any] = ["target": 0]
        if let dataURL { payload["image"] = dataURL }   // absent = the manifest's image
        sendOnce(context, "image", ["event": "setImage", "context": context, "payload": payload])
    }

    private func setState(_ context: String, _ value: Int) {
        sendOnce(context, "state", ["event": "setState", "context": context, "payload": ["state": value]])
    }

    private func feedback(_ context: String, _ payload: [String: Any]) {
        sendOnce(context, "feedback", ["event": "setFeedback", "context": context, "payload": payload])
    }

    private func forget(_ context: String) {
        lastSent = lastSent.filter { !$0.key.hasPrefix(context + "|") }
    }

    /// Skips a message identical to the last one of its kind for that context.
    /// A poll twice a second would otherwise redraw every key twice a second.
    private func sendOnce(_ context: String, _ kind: String, _ message: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: message, options: .sortedKeys),
              let text = String(data: data, encoding: .utf8) else { return }
        let slot = context + "|" + kind
        guard lastSent[slot] != text else { return }
        lastSent[slot] = text
        socket.send(.string(text)) { _ in }
    }

    private func short(_ text: String, _ limit: Int) -> String {
        text.count <= limit ? text : String(text.prefix(limit - 1)) + "…"
    }

    private func clock(_ seconds: Double) -> String {
        let total = Int(max(0, seconds))
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}

// MARK: - Keys

enum Keys {
    /// Same reading of a key name as Studio One's: "F♯m", "Gb", "A#m".
    static func root(_ key: String) -> Int? {
        var text = key.trimmingCharacters(in: .whitespaces)
        let lower = text.lowercased()
        if lower.hasSuffix("m") && !lower.hasSuffix("maj") { text.removeLast() }
        let naturals: [Character: Int] = ["C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11]
        guard let head = text.first, var index = naturals[Character(head.uppercased())] else { return nil }
        let rest = text.dropFirst()
        if rest.hasPrefix("♯") || rest.hasPrefix("#") { index += 1 }
        if rest.hasPrefix("♭") || rest.hasPrefix("b") { index -= 1 }
        return (index % 12 + 12) % 12
    }

    /// Semitones from the detected key to the one in use, folded into −6…+6.
    static func shift(from detected: String?, to current: String?) -> Int? {
        guard let detected, let current, let a = root(detected), let b = root(current) else { return nil }
        let raw = ((b - a) % 12 + 12) % 12
        return raw > 6 ? raw - 12 : raw
    }
}

let deck = Deck()
deck.connect()
RunLoop.main.run()
