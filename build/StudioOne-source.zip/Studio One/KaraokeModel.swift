import Foundation
import AppKit
import Combine
import QuartzCore

enum LyricsState: Equatable {
    case idle
    case loading
    case synced
    case plain(String)
    case instrumental
    case missing
}

@MainActor
final class KaraokeModel: ObservableObject {

    // MARK: Published state

    @Published private(set) var track: SpotifyTrack?
    @Published private(set) var playerState: SpotifyPlayerState = .stopped
    @Published private(set) var lines: [LyricLine] = []
    @Published private(set) var lyricsState: LyricsState = .idle
    @Published private(set) var analysis: TrackAnalysis?

    /// Where the beat grid sits, estimated once per track rather than per frame.
    @Published private(set) var beatOffset: Double = 0

    /// Colours lifted from the current cover art. Empty falls back to Theme.
    @Published private(set) var palette: [PaletteColor] = []

    /// Cover art for players that supply image data instead of a URL — Apple
    /// Music. Nil on Spotify, where `track.artworkURL` is used directly.
    @Published private(set) var localArtwork: NSImage?

    /// Halves or doubles the reported tempo. Sources sometimes read a track at
    /// half time — the only tempo error large enough to hear — and this is the
    /// correction. Saved per track, like the sync trim.
    @Published var tempoMultiplier: Double = 1 {
        didSet {
            persistTempoMultiplier()
            MIDIBridge.shared.publish(publishedAnalysis)
            refreshBeatOffset()
        }
    }

    /// Key and tempo typed in by hand, for tracks no source has data for.
    @Published var manualKey: String? { didSet { persistManual(); republish() } }
    @Published var manualTempo: Double? { didSet { persistManual(); republish() } }

    var hasManualValues: Bool { manualKey != nil || manualTempo != nil }

    /// Analysis as it should be shown and transmitted. Hand-entered values win
    /// outright; the ×2/÷2 correction only applies to what a source reported.
    var publishedAnalysis: TrackAnalysis? {
        var result = analysis ?? TrackAnalysis()

        if let manualKey { result.key = manualKey }
        if let manualTempo {
            result.tempo = manualTempo
        } else if let tempo = result.tempo {
            result.tempo = tempo * tempoMultiplier
        }
        return result.isEmpty ? nil : result
    }

    /// No source had key or tempo, so put the track on the clipboard — the next
    /// step is searching for it by hand, and this saves retyping an artist like
    /// "Zero 9:36". Skipped when values were entered manually, since those
    /// already answer the question.
    private func copyTitleIfUnknown(_ track: SpotifyTrack) {
        let enabled = UserDefaults.standard.object(forKey: Self.copyOnMissKey) as? Bool ?? true
        guard enabled, publishedAnalysis == nil else { return }

        let text = "\(track.name) - \(track.artist)"
        let board = NSPasteboard.general
        board.clearContents()
        board.setString(text, forType: .string)

        status = "No key or tempo found — “\(text)” copied to the clipboard."
    }

    /// Recomputed whenever either input lands — the lyrics and the tempo arrive
    /// from different requests and either can be first.
    private func refreshBeatOffset() {
        guard let tempo = publishedAnalysis?.tempo, !lines.isEmpty else {
            beatOffset = 0
            return
        }
        beatOffset = LRCParser.beatOffset(lines: lines, bpm: tempo)
        Diagnostics.log("  beat grid: \(String(format: "%.0f", tempo)) bpm, offset \(Int(beatOffset * 1000)) ms")
    }

    private func republish() {
        MIDIBridge.shared.publish(publishedAnalysis)
    }

    /// Output-device latency, measured and applied without user involvement.
    @Published private(set) var automaticLatencyMilliseconds: Double = 0
    @Published private(set) var connection: ConnectionState = .checking
    @Published var status: String?

    /// Manual sync trim, in milliseconds. Positive = lyrics run ahead of the music.
    @Published var offsetMilliseconds: Double = 0 {
        didSet { persistOffset() }
    }

    @Published var searchQuery: String = ""
    @Published private(set) var searchResults: [SearchResult] = []
    @Published private(set) var isSearching = false

    enum ConnectionState: Equatable {
        case checking
        case ready
        case spotifyNotRunning
        case permissionDenied
        case failed(String)
    }

    // MARK: Internals

    let clock = PlaybackClock()

    private var controller: MusicPlayer?

    /// Which player is driving. Changing it tears the old one down and starts
    /// the other, so the switch takes effect without relaunching.
    @Published var musicSource: MusicSource = {
        let stored = UserDefaults.standard.string(forKey: MusicSource.defaultsKey)
        return stored.flatMap(MusicSource.init(rawValue:)) ?? .spotify
    }()
    private var pollTimer: Timer?
    private var playbackObserver: NSObjectProtocol?
    private var lyricsTask: Task<Void, Never>?
    private var analysisTask: Task<Void, Never>?
    private var paletteTask: Task<Void, Never>?
    private var searchTask: Task<Void, Never>?
    private var lastTrackURI: String?

    private let pollInterval: TimeInterval = 0.5
    private let offsetDefaultsKey = "trackOffsets"
    private let tempoDefaultsKey = "trackTempoMultipliers"
    private let manualKeyDefaultsKey = "trackManualKeys"
    private let manualTempoDefaultsKey = "trackManualTempos"
    static let copyOnMissKey = "copyTitleWhenUnknown"

    var isPlaying: Bool { playerState == .playing }

    /// Playback position, automatically compensated for output latency, with the
    /// user's manual trim folded in on top.
    ///
    /// Spotify reports where the playhead is, not what has reached your ears.
    /// Subtracting the measured device latency is what removes the need to dial
    /// the sync slider in by hand every time you put headphones on.
    /// Raw playback position. `lyricPosition` shifts this by the sync offset
    /// and the measured output latency, which is right for the lyrics and wrong
    /// for a progress bar.
    var playbackPosition: Double { clock.position }

    var lyricPosition: Double {
        clock.position + (offsetMilliseconds - automaticLatencyMilliseconds) / 1000
    }

    // MARK: Lifecycle

    func start() {
        // Both windows call this on appear, and a window can reappear. Without
        // this guard each call would add another observer and leave the previous
        // timer scheduled on the run loop, polling forever.
        guard pollTimer == nil else { return }

        Diagnostics.startSession()
        ControlServer.shared.start(model: self)

        do {
            controller = try makeController()
            Diagnostics.log("\(musicSource.displayName) controller ready")
        } catch {
            Diagnostics.log("ERROR controller init failed: \(error.localizedDescription)")
            connection = .failed(error.localizedDescription)
            return
        }

        // Publishes the virtual MIDI source Logic can learn from.
        MIDIBridge.shared.start()

        // Off the main thread and detached, for the same reason the diagnostics
        // header doesn't read the keychain: a credential read can raise an
        // authorisation prompt, and blocking the launch path behind one looks
        // exactly like a freeze.
        Task.detached(priority: .utility) { await SpotifyAPI.shared.warm() }

        // Triggers the one-time macOS consent dialog on first launch.
        //
        // Deliberately off the main thread: with prompting enabled this blocks
        // until the user answers the dialog. Called on the main thread it stalls
        // the app before it draws — which looks exactly like a freeze on any Mac
        // that hasn't granted automation yet, and survives a force quit because
        // the next launch blocks in the same place.
        let bundleID = musicSource.bundleID
        DispatchQueue.global(qos: .userInitiated).async {
            _ = SpotifyController.checkAutomationPermission(for: bundleID, prompt: true)
        }

        // Spotify broadcasts on every play, pause, seek and track change.
        // We use it purely as a "poll right now" signal rather than trusting its payload.
        playbackObserver = DistributedNotificationCenter.default().addObserver(
            forName: Notification.Name("com.spotify.client.PlaybackStateChanged"),
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.poll() }
        }

        poll()
        let timer = Timer(timeInterval: pollInterval, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.poll() }
        }
        // .common keeps polling alive while the user drags the offset slider.
        RunLoop.main.add(timer, forMode: .common)
        pollTimer = timer
    }

    func stop() {
        pollTimer?.invalidate()
        pollTimer = nil
        if let playbackObserver {
            DistributedNotificationCenter.default().removeObserver(playbackObserver)
            self.playbackObserver = nil
        }
        lyricsTask?.cancel()
        analysisTask?.cancel()
        paletteTask?.cancel()
        searchTask?.cancel()
    }

    // MARK: Polling

    /// Guards against a slow Apple Event letting polls stack up.
    private var polling = false

    private func poll() {
        guard let controller, !polling else { return }
        polling = true

        Task { @MainActor [weak self] in
            guard let self else { return }
            defer { self.polling = false }

            do {
                let snapshot = try await controller.snapshot()
                let latency = await AudioLatency.measuredMilliseconds()
                self.apply(snapshot: snapshot, latency: latency)
            } catch {
                self.handle(error)
            }
        }
    }

    private func apply(snapshot: SpotifySnapshot, latency: Double) {
        if connection != .ready { Diagnostics.log("connection: ready") }
        connection = .ready

        // Assign `track` first: handleTrackChange writes the saved offset, and
        // persistOffset keys off the *current* track.
        let changed = snapshot.track?.uri != lastTrackURI
        lastTrackURI = snapshot.track?.uri
        track = snapshot.track
        if changed { handleTrackChange(snapshot.track) }

        playerState = snapshot.state

        if abs(latency - automaticLatencyMilliseconds) > 1 {
            Diagnostics.log("output latency: \(Int(latency)) ms (applied automatically)")
            automaticLatencyMilliseconds = latency
        }

        clock.ingest(sample: snapshot.position,
                     sampledAt: snapshot.sampledAt,
                     playing: snapshot.state == .playing)
    }

    private func handle(_ error: Error) {
        let next: ConnectionState
        if let error = error as? SpotifyControllerError {
            switch error {
            case .notRunning:    next = .spotifyNotRunning
            case .notAuthorized: next = .permissionDenied
            default:             next = .failed(error.localizedDescription)
            }
        } else {
            next = .failed(error.localizedDescription)
        }

        if connection != next {
            Diagnostics.log("connection: \(next) — \(error.localizedDescription)")
        }
        connection = next
    }

    private func handleTrackChange(_ newTrack: SpotifyTrack?) {
        lyricsTask?.cancel()
        analysisTask?.cancel()
        paletteTask?.cancel()
        status = nil
        lines = []
        analysis = nil
        palette = []
        clock.reset(to: 0, playing: false)

        guard let newTrack else {
            Diagnostics.log("track: none")
            lyricsState = .idle
            offsetMilliseconds = 0
            MIDIBridge.shared.stopClock()
            return
        }

        Diagnostics.log("track: \(newTrack.name) — \(newTrack.artist) [\(newTrack.trackID)] \(Int(newTrack.duration))s")
        Diagnostics.log("  sync: trim \(Int(storedOffset(for: newTrack.trackID))) ms + auto -\(Int(automaticLatencyMilliseconds)) ms")

        paletteTask = Task { [weak self] in
            guard let self else { return }

            // A URL is the fast path. Without one, ask the player for the image
            // itself — that is the only route on Apple Music.
            if newTrack.artworkURL == nil, let browser = self.browser {
                let image = await browser.currentArtwork().flatMap(NSImage.init(data:))
                guard !Task.isCancelled, self.track?.uri == newTrack.uri else { return }
                self.localArtwork = image
                self.palette = image.map { PaletteProvider.shared.palette(for: $0) } ?? []
                return
            }

            self.localArtwork = nil
            let colours = await PaletteProvider.shared.palette(for: newTrack)
            guard !Task.isCancelled, self.track?.uri == newTrack.uri else { return }
            self.palette = colours
        }

        analysisTask = Task { [weak self] in
            let result = await AnalysisProvider.shared.analysis(for: newTrack)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                guard let self, self.track?.uri == newTrack.uri else { return }
                self.analysis = result
                self.refreshBeatOffset()
                if let result {
                    Diagnostics.log("analysis: key=\(result.key ?? "-") tempo=\(result.tempo.map { String(format: "%.2f", $0) } ?? "-")\(result.halfTimeSuspect ? " HALF-TIME SUSPECT" : "")")
                } else {
                    Diagnostics.log("analysis: nothing from any source")
                }
                MIDIBridge.shared.publish(self.publishedAnalysis)
                self.copyTitleIfUnknown(newTrack)
            }
        }

        offsetMilliseconds = storedOffset(for: newTrack.trackID)
        tempoMultiplier = storedTempoMultiplier(for: newTrack.trackID)
        let manuals = storedManual(for: newTrack.trackID)
        manualKey = manuals.key
        manualTempo = manuals.tempo
        lyricsState = .loading

        lyricsTask = Task { [weak self] in
            let result = await LyricsProvider.shared.lyrics(for: newTrack)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                guard let self, self.track?.uri == newTrack.uri else { return }
                self.apply(result)
            }
        }
    }

    private func apply(_ result: LyricsResult) {
        switch result {
        case .synced(let lines):
            Diagnostics.log("lyrics: synced, \(lines.count) lines")
        case .plain:
            Diagnostics.log("lyrics: plain only (untimed)")
        case .instrumental:
            Diagnostics.log("lyrics: instrumental")
        case .notFound:
            Diagnostics.log("lyrics: not found")
        }

        switch result {
        case .synced(let parsed):
            lines = parsed
            lyricsState = .synced
            refreshBeatOffset()
        case .plain(let text):
            lines = []
            lyricsState = .plain(text)
        case .instrumental:
            lines = []
            lyricsState = .instrumental
        case .notFound:
            lines = []
            lyricsState = .missing
        }
    }

    func reloadLyrics() {
        guard let track else { return }
        Task {
            await LyricsProvider.shared.invalidate(trackID: track.trackID)
            handleTrackChange(track)
        }
    }

    // MARK: Transport

    func togglePlayback() { perform { try $0.playPause() } }
    func nextTrack() { perform { try $0.next() } }
    func previousTrack() { perform { try $0.previous() } }
    /// Correct the key by semitones from the remote.
    ///
    /// This writes `manualKey`, the same override the control bar sets, so it
    /// persists per track and republishes to Logic. It corrects what the app
    /// *believes* the key is — it cannot transpose the audio, which comes from
    /// Apple Music as a finished mix.
    func nudgeKey(by semitones: Int) {
        if let current = publishedAnalysis?.key,
           let coded = MIDIBridge.encode(key: current) {
            manualKey = MIDIBridge.decode(root: coded.root + semitones, minor: coded.minor)
        } else {
            // Nothing was detected. Start at C rather than doing nothing —
            // a track with no analysis is exactly when a manual value is
            // wanted, and a dead button reads as broken.
            manualKey = MIDIBridge.decode(root: 0, minor: false)
        }
    }

    /// Correct the tempo by whole BPM, with the same caveat.
    func nudgeTempo(by delta: Double) {
        guard let current = publishedAnalysis?.tempo else {
            manualTempo = 120          // same reasoning as the key
            return
        }
        manualTempo = min(250, max(40, (current + delta).rounded()))
    }

    /// Clear both corrections and fall back to what the lookup found.
    func clearNudges() {
        manualKey = nil
        manualTempo = nil
    }

    func revealPlayer() { controller?.activate() }

    /// The library browser for the current source, when it has one. Only Apple
    /// Music does — see the note on `MusicBrowser`.
    var browser: MusicBrowser? { controller as? MusicBrowser }
    var canSearch: Bool { controller?.supportsPlayingByID ?? false }

    func seek(to seconds: Double) {
        perform { try $0.seek(to: seconds) }
        clock.reset(to: seconds, playing: isPlaying)
    }

    /// Jump to the start of a lyric line — handy for practising one verse.
    func jump(to line: LyricLine) {
        seek(to: max(0, line.time - offsetMilliseconds / 1000))
    }

    func play(_ result: SearchResult) {
        perform { try $0.play(uri: result.uri) }
        searchResults = []
        searchQuery = ""
    }

    /// Rebuilds the controller for the selected source. Safe to call while
    /// running — polling continues against whichever player is now active.
    func changeSource(to newSource: MusicSource) {
        guard newSource != musicSource else { return }
        Diagnostics.log("source: switching to \(newSource.displayName)")

        musicSource = newSource
        UserDefaults.standard.set(newSource.rawValue, forKey: MusicSource.defaultsKey)

        lastTrackURI = nil
        track = nil
        handleTrackChange(nil)
        connection = .checking

        do {
            controller = try makeController()
            Diagnostics.log("\(newSource.displayName) controller ready")
        } catch {
            Diagnostics.log("ERROR controller init failed: \(error.localizedDescription)")
            controller = nil
            connection = .failed(error.localizedDescription)
            return
        }

        // Consent is per-application, so a first switch prompts once. Off the
        // main thread — that call blocks until the dialog is answered.
        let bundleID = newSource.bundleID
        DispatchQueue.global(qos: .userInitiated).async {
            _ = SpotifyController.checkAutomationPermission(for: bundleID, prompt: true)
        }

        poll()
    }

    private func makeController() throws -> MusicPlayer {
        switch musicSource {
        case .spotify:    return try SpotifyController()
        case .appleMusic: return try AppleMusicController()
        }
    }

    private func perform(_ action: (MusicPlayer) throws -> Void) {
        guard let controller else { return }
        do {
            try action(controller)
            status = nil
        } catch {
            Diagnostics.log("ERROR transport: \(error.localizedDescription)")
            status = error.localizedDescription
        }
    }

    // MARK: Search

    func runSearch() {
        searchTask?.cancel()
        let query = searchQuery

        guard query.trimmingCharacters(in: .whitespaces).count >= 2 else {
            searchResults = []
            return
        }

        searchTask = Task { [weak self] in
            // Debounce so we don't fire a request per keystroke.
            try? await Task.sleep(nanoseconds: 300_000_000)
            guard !Task.isCancelled else { return }

            await MainActor.run { self?.isSearching = true }
            do {
                let results = try await SpotifyAPI.shared.search(query)
                guard !Task.isCancelled else { return }
                await MainActor.run {
                    self?.searchResults = results
                    self?.isSearching = false
                    self?.status = results.isEmpty ? "No tracks matched “\(query)”." : nil
                }
            } catch {
                await MainActor.run {
                    Diagnostics.log("ERROR search: \(error.localizedDescription)")
                    self?.isSearching = false
                    self?.status = error.localizedDescription
                }
            }
        }
    }

    // MARK: Offset persistence

    private func storedOffset(for trackID: String) -> Double {
        let map = UserDefaults.standard.dictionary(forKey: offsetDefaultsKey) as? [String: Double] ?? [:]
        return map[trackID] ?? 0
    }

    private func storedTempoMultiplier(for trackID: String) -> Double {
        let map = UserDefaults.standard.dictionary(forKey: tempoDefaultsKey) as? [String: Double] ?? [:]
        return map[trackID] ?? 1
    }

    private func persistTempoMultiplier() {
        guard let trackID = track?.trackID else { return }
        var map = UserDefaults.standard.dictionary(forKey: tempoDefaultsKey) as? [String: Double] ?? [:]
        if tempoMultiplier == 1 {
            map.removeValue(forKey: trackID)
        } else {
            map[trackID] = tempoMultiplier
        }
        UserDefaults.standard.set(map, forKey: tempoDefaultsKey)
    }

    private func storedManual(for trackID: String) -> (key: String?, tempo: Double?) {
        let keys = UserDefaults.standard.dictionary(forKey: manualKeyDefaultsKey) as? [String: String] ?? [:]
        let tempos = UserDefaults.standard.dictionary(forKey: manualTempoDefaultsKey) as? [String: Double] ?? [:]
        return (keys[trackID], tempos[trackID])
    }

    private func persistManual() {
        guard let trackID = track?.trackID else { return }

        var keys = UserDefaults.standard.dictionary(forKey: manualKeyDefaultsKey) as? [String: String] ?? [:]
        keys[trackID] = manualKey
        UserDefaults.standard.set(keys, forKey: manualKeyDefaultsKey)

        var tempos = UserDefaults.standard.dictionary(forKey: manualTempoDefaultsKey) as? [String: Double] ?? [:]
        tempos[trackID] = manualTempo
        UserDefaults.standard.set(tempos, forKey: manualTempoDefaultsKey)
    }

    private func persistOffset() {
        guard let trackID = track?.trackID else { return }
        var map = UserDefaults.standard.dictionary(forKey: offsetDefaultsKey) as? [String: Double] ?? [:]
        if offsetMilliseconds == 0 {
            map.removeValue(forKey: trackID)
        } else {
            map[trackID] = offsetMilliseconds
        }
        UserDefaults.standard.set(map, forKey: offsetDefaultsKey)
    }

    // MARK: Lyric lookup

    /// Index of the line that should be lit up right now, or nil before the first line.
    func activeIndex(at position: Double) -> Int? {
        guard !lines.isEmpty else { return nil }
        var low = 0
        var high = lines.count - 1
        var found: Int? = nil
        while low <= high {
            let mid = (low + high) / 2
            if lines[mid].time <= position {
                found = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return found
    }
}
